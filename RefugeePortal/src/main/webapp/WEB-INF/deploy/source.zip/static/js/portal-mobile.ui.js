$(function() {
	// ２行以上入力されたら TEXTAREA の高さを変える
	$('textarea').on('input', function(evt){
		if (evt.target.scrollHeight > 43) {
			if (evt.target.scrollHeight > evt.target.offsetHeight) {
				$(evt.target).height(evt.target.scrollHeight);
			} else {
				var lineHeight = Number($(evt.target).css('lineHeight').split('px')[0]);
				while (true) {
					$(evt.target).height($(evt.target).height() - lineHeight);

					if (evt.target.scrollHeight > evt.target.offsetHeight) {
						$(evt.target).height(evt.target.scrollHeight);
						break;
					}
				}
			}
		}
	});

	// 入力されてない TEXTAREA の高さを元に戻す
	$('textarea').on('blur', function(evt){
		var t = $(evt.target).val();
		if (t == '') {
			$(evt.target).css('height', '44px');
		}
	});
});
